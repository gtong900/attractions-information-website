﻿function chooseBtnClick() {
    var calendar = document.getElementById("Calendar1");
    calendar.style.visibility = true;
}